using BepInEx;
using Photon.Pun;
using MalachiTemp.Backend;
using MalachiTemp.UI;
using UnityEngine;
using MalachiTemp.Utilities;

namespace dfgsfe
{
    /*
       PROTECTION NOTE: THIS TEMPLATE IS PROTECTED MATERIAL FROM "Project Malachi". 
       IF ANY MATERIAL FROM "MalachiTemp" FOUND IN ANY Page9 PROJECT/THING WITHOUT 
       CREDIT OR PERMISSION MUST AND WILL BE REMOVED IMMEDIATELY
    */
    [BepInPlugin("malachis.temp", "malachis.temp.GUI", "1.0.0")]
    public class Gui : BaseUnityPlugin
    {
        // Double click a grey square to open it, click the - in the box to the left of "#region" to close it
        #region Gui
        public void OnGUI()
        {
            if (open)
            {
                GUI.color = Color.Lerp(WristMenu.menuObj.GetComponent<ColorChanger>().color, WristMenu.menuObj.GetComponent<ColorChanger>().color, Mathf.PingPong(Time.time, 1f));
                GUI.backgroundColor = Color.Lerp(WristMenu.menuObj.GetComponent<ColorChanger>().color, WristMenu.menuObj.GetComponent<ColorChanger>().color, Mathf.PingPong(Time.time, 1f));
                GUI.contentColor = Color.Lerp(WristMenu.menuObj.GetComponent<ColorChanger>().color, WristMenu.menuObj.GetComponent<ColorChanger>().color, Mathf.PingPong(Time.time, 1f));

                GUI.Label(new Rect(4f, 5f, 500f, 500f), "<color=white>|\n|\n|\n|\n|\n|\n|\n|\n|\n|\n|\n|\n|\n|\n|\n|\n|\n|\n|</color>");
                GUI.Label(new Rect(100f, 5f, 500f, 500f), "<color=white>|\n|\n|\n|\n|\n|\n|\n|\n|\n|\n|\n|\n|\n|\n|\n|\n|</color>");
                GUI.Label(new Rect(259f, 5f, 500f, 500f), "<color=white>|\n|\n|\n|\n|\n|\n|\n|\n|\n|\n|\n|\n|\n|\n|\n|\n|\n|\n|</color>");
                GUI.Label(new Rect(5f, 0f, 500f, 500f), "<color=white>----------------------------------------------------------------</color>");
                GUI.Label(new Rect(5f, 250f, 500f, 500f), "<color=white>----------------------------------------------------------------</color>");
                GUI.Label(new Rect(5f, 280f, 500f, 500f), "<color=white>----------------------------------------------------------------</color>");
                if (GUI.Button(new Rect(10f, 265f, 247f, 25f), "<color=white>Disconnect</color>"))
                {
                    PhotonNetwork.Disconnect();
                    GorillaTagger.Instance.offlineVRRig.PlayHandTapLocal(Mods.ButtonSound, false, 0.1f);
                }
                if (GUI.Button(new Rect(10f, 15f, 90f, 20f), "<color=white>Settings</color>"))
                {
                    Page1 = false;
                    Page2 = false;
                    Page3 = false;
                    Page4 = false;
                    Page5 = false;
                    Page10 = false;
                    Page6 = false;
                    Page7 = false;
                    Page8 = false;
                    Page9 = false;
                    Settings = !Settings;
                }
                if (Settings)
                {
                    float scrollHeight = WristMenu.settingsbuttons.Count * (20 + 7 + 99);
                    scrollPosition = GUI.BeginScrollView(new Rect(100, 15, 150, 250), scrollPosition, new Rect(0, 0, Screen.width - 40, scrollHeight + 20));
                    for (int i = 0; i < WristMenu.settingsbuttons.Count; i++)
                    {
                        Rect buttonRect = new Rect(10, 15 + i * (20 + 7), 150, 20);
                        if (GUI.Button(buttonRect, "<color=white>" + WristMenu.settingsbuttons[i].buttonText + "</color>"))
                        {
                            WristMenu.settingsbuttons[i].enabled = !WristMenu.settingsbuttons[i].enabled;
                            WristMenu.lastPressedButtonIndex = i;
                            GorillaTagger.Instance.offlineVRRig.PlayHandTapLocal(Mods.ButtonSound, false, 0.1f);
                        }
                    }
                    GUI.EndScrollView();
                }
                if (GUI.Button(new Rect(10f, 37f, 90f, 20f), "<color=white>" + WristMenu.buttons[3].buttonText + "</color>"))
                {
                    Settings = false;
                    Page2 = false;
                    Page4 = false;
                    Page6 = false;
                    Page5 = false;
                    Page10 = false;
                    Page7 = false;
                    Page3 = false;
                    Page8 = false;
                    Page9 = false;
                    Page1 = !Page1;
                }
                if (Page1)
                {
                    float scrollHeight = WristMenu.CatButtons1.Count * (20 + 7 + 99);
                    scrollPosition = GUI.BeginScrollView(new Rect(100, 15, 150, 250), scrollPosition, new Rect(0, 0, Screen.width - 40, scrollHeight + 20));
                    for (int i = 0; i < WristMenu.CatButtons1.Count; i++)
                    {
                        Rect buttonRect = new Rect(10, 15 + i * (20 + 7), 150, 20);
                        if (GUI.Button(buttonRect, "<color=white>" + WristMenu.CatButtons1[i].buttonText + "</color>"))
                        {
                            WristMenu.CatButtons1[i].enabled = !WristMenu.CatButtons1[i].enabled;
                            WristMenu.lastPressedButtonIndex = i;
                            GorillaTagger.Instance.offlineVRRig.PlayHandTapLocal(Mods.ButtonSound, false, 0.1f);
                        }
                    }
                    GUI.EndScrollView();
                }
                if (GUI.Button(new Rect(10f, 59f, 90f, 20f), "<color=white>" + WristMenu.buttons[4].buttonText + "</color>"))
                {
                    Page1 = false;
                    Settings = false;
                    Page4 = false;
                    Page6 = false;
                    Page5 = false;
                    Page7 = false;
                    Page3 = false;
                    Page10 = false;
                    Page8 = false;
                    Page9 = false;
                    Page2 = !Page2;
                }
                if (Page2)
                {
                    float scrollHeight = WristMenu.CatButtons2.Count * (20 + 7 + 99);
                    scrollPosition = GUI.BeginScrollView(new Rect(100, 15, 150, 250), scrollPosition, new Rect(0, 0, Screen.width - 40, scrollHeight + 20));
                    for (int i = 0; i < WristMenu.CatButtons2.Count; i++)
                    {
                        Rect buttonRect = new Rect(10, 15 + i * (20 + 7), 150, 20);
                        if (GUI.Button(buttonRect, "<color=white>" + WristMenu.CatButtons2[i].buttonText + "</color>"))
                        {
                            WristMenu.CatButtons2[i].enabled = !WristMenu.CatButtons2[i].enabled;
                            WristMenu.lastPressedButtonIndex = i;
                            GorillaTagger.Instance.offlineVRRig.PlayHandTapLocal(Mods.ButtonSound, false, 0.1f);
                        }
                    }
                    GUI.EndScrollView();
                }
                if (GUI.Button(new Rect(10f, 81f, 90f, 20f), "<color=white>" + WristMenu.buttons[5].buttonText + "</color>"))
                {
                    Page1 = false;
                    Page2 = false;
                    Page4 = false;
                    Page6 = false;
                    Page5 = false;
                    Page7 = false;
                    Settings = false;
                    Page10 = false;
                    Page8 = false;
                    Page9 = false;
                    Page3 = !Page3;
                }
                if (Page3)
                {
                    float scrollHeight = WristMenu.CatButtons3.Count * (20 + 7 + 99);
                    scrollPosition = GUI.BeginScrollView(new Rect(100, 15, 150, 250), scrollPosition, new Rect(0, 0, Screen.width - 40, scrollHeight + 20));
                    for (int i = 0; i < WristMenu.CatButtons3.Count; i++)
                    {
                        Rect buttonRect = new Rect(10, 15 + i * (20 + 7), 150, 20);
                        if (GUI.Button(buttonRect, "<color=white>" + WristMenu.CatButtons3[i].buttonText + "</color>"))
                        {
                            WristMenu.CatButtons3[i].enabled = !WristMenu.CatButtons3[i].enabled;
                            WristMenu.lastPressedButtonIndex = i;
                            GorillaTagger.Instance.offlineVRRig.PlayHandTapLocal(Mods.ButtonSound, false, 0.1f);
                        }
                    }
                    GUI.EndScrollView();
                }
                if (GUI.Button(new Rect(10f, 102f, 90f, 20f), "<color=white>" + WristMenu.buttons[6].buttonText + "</color>"))
                {
                    Page1 = false;
                    Page2 = false;
                    Page10 = false;
                    Settings = false;
                    Page6 = false;
                    Page5 = false;
                    Page7 = false;
                    Page3 = false;
                    Page8 = false;
                    Page9 = false;
                    Page4 = !Page4;
                }
                if (Page4)
                {
                    float scrollHeight = WristMenu.CatButtons4.Count * (20 + 7 + 99);
                    scrollPosition = GUI.BeginScrollView(new Rect(100, 15, 150, 250), scrollPosition, new Rect(0, 0, Screen.width - 40, scrollHeight + 20));
                    for (int i = 0; i < WristMenu.CatButtons4.Count; i++)
                    {
                        Rect buttonRect = new Rect(10, 15 + i * (20 + 7), 150, 20);
                        if (GUI.Button(buttonRect, "<color=white>" + WristMenu.CatButtons4[i].buttonText + "</color>"))
                        {
                            WristMenu.CatButtons4[i].enabled = !WristMenu.CatButtons4[i].enabled;
                            WristMenu.lastPressedButtonIndex = i;
                            GorillaTagger.Instance.offlineVRRig.PlayHandTapLocal(Mods.ButtonSound, false, 0.1f);
                        }
                    }
                    GUI.EndScrollView();
                }
                if (GUI.Button(new Rect(10f, 124f, 90f, 20f), "<color=white>" + WristMenu.buttons[7].buttonText + "</color>"))
                {
                    Page1 = false;
                    Page2 = false;
                    Page4 = false;
                    Page6 = false;
                    Settings = false;
                    Page7 = false;
                    Page10 = false;
                    Page3 = false;
                    Page8 = false;
                    Page9 = false;
                    Page5 = !Page5;
                }
                if (Page5)
                {
                    float scrollHeight = WristMenu.CatButtons5.Count * (20 + 7 + 99);
                    scrollPosition = GUI.BeginScrollView(new Rect(100, 15, 150, 250), scrollPosition, new Rect(0, 0, Screen.width - 40, scrollHeight + 20));
                    for (int i = 0; i < WristMenu.CatButtons5.Count; i++)
                    {
                        Rect buttonRect = new Rect(10, 15 + i * (20 + 7), 150, 20);
                        if (GUI.Button(buttonRect, "<color=white>" + WristMenu.CatButtons5[i].buttonText + "</color>"))
                        {
                            WristMenu.CatButtons5[i].enabled = !WristMenu.CatButtons5[i].enabled;
                            WristMenu.lastPressedButtonIndex = i;
                            GorillaTagger.Instance.offlineVRRig.PlayHandTapLocal(Mods.ButtonSound, false, 0.1f);
                        }
                    }
                    GUI.EndScrollView();
                }
                if (GUI.Button(new Rect(10f, 146f, 90f, 20f), "<color=white>" + WristMenu.buttons[8].buttonText + "</color>"))
                {
                    Page1 = false;
                    Page2 = false;
                    Page4 = false;
                    Settings = false;
                    Page5 = false;
                    Page10 = false;
                    Page7 = false;
                    Page3 = false;
                    Page8 = false;
                    Page9 = false;
                    Page6 = !Page6;
                }
                if (Page6)
                {
                    float scrollHeight = WristMenu.CatButtons6.Count * (20 + 7 + 99);
                    scrollPosition = GUI.BeginScrollView(new Rect(100, 15, 150, 250), scrollPosition, new Rect(0, 0, Screen.width - 40, scrollHeight + 20));
                    for (int i = 0; i < WristMenu.CatButtons6.Count; i++)
                    {
                        Rect buttonRect = new Rect(10, 15 + i * (20 + 7), 150, 20);
                        if (GUI.Button(buttonRect, "<color=white>" + WristMenu.CatButtons6[i].buttonText + "</color>"))
                        {
                            WristMenu.CatButtons6[i].enabled = !WristMenu.CatButtons6[i].enabled;
                            WristMenu.lastPressedButtonIndex = i;
                            GorillaTagger.Instance.offlineVRRig.PlayHandTapLocal(Mods.ButtonSound, false, 0.1f);
                        }
                    }
                    GUI.EndScrollView();
                }
                if (GUI.Button(new Rect(10f, 168f, 90f, 20f), "<color=white>" + WristMenu.buttons[9].buttonText + "</color>"))
                {
                    Page1 = false;
                    Page2 = false;
                    Page4 = false;
                    Page6 = false;
                    Page10 = false;
                    Page5 = false;
                    Settings = false;
                    Page3 = false;
                    Page8 = false;
                    Page9 = false;
                    Page7 = !Page7;
                }
                if (Page7)
                {
                    float scrollHeight = WristMenu.CatButtons7.Count * (20 + 7 + 99);
                    scrollPosition = GUI.BeginScrollView(new Rect(100, 15, 150, 250), scrollPosition, new Rect(0, 0, Screen.width - 40, scrollHeight + 20));
                    for (int i = 0; i < WristMenu.CatButtons7.Count; i++)
                    {
                        Rect buttonRect = new Rect(10, 15 + i * (20 + 7), 150, 20);
                        if (GUI.Button(buttonRect, "<color=white>" + WristMenu.CatButtons7[i].buttonText + "</color>"))
                        {
                            WristMenu.CatButtons7[i].enabled = !WristMenu.CatButtons7[i].enabled;
                            WristMenu.lastPressedButtonIndex = i;
                            GorillaTagger.Instance.offlineVRRig.PlayHandTapLocal(Mods.ButtonSound, false, 0.1f);
                        }
                    }
                    GUI.EndScrollView();
                }
                if (GUI.Button(new Rect(10f, 190f, 90f, 20f), "<color=white>" + WristMenu.buttons[10].buttonText + "</color>"))
                {
                    Page1 = false;
                    Page2 = false;
                    Page4 = false;
                    Page6 = false;
                    Page5 = false;
                    Page7 = false;
                    Page3 = false;
                    Page10 = false;
                    Settings = false;
                    Page9 = false;
                    Page8 = !Page8;
                }
                if (Page8)
                {
                    float scrollHeight = WristMenu.CatButtons8.Count * (20 + 7 + 99);
                    scrollPosition = GUI.BeginScrollView(new Rect(100, 15, 150, 250), scrollPosition, new Rect(0, 0, Screen.width - 40, scrollHeight + 20));
                    for (int i = 0; i < WristMenu.CatButtons8.Count; i++)
                    {
                        Rect buttonRect = new Rect(10, 15 + i * (20 + 7), 150, 20);
                        if (GUI.Button(buttonRect, "<color=white>" + WristMenu.CatButtons8[i].buttonText + "</color>"))
                        {
                            WristMenu.CatButtons8[i].enabled = !WristMenu.CatButtons8[i].enabled;
                            WristMenu.lastPressedButtonIndex = i;
                            GorillaTagger.Instance.offlineVRRig.PlayHandTapLocal(Mods.ButtonSound, false, 0.1f);
                        }
                    }
                    GUI.EndScrollView();
                }
                if (GUI.Button(new Rect(10f, 212f, 90f, 20f), "<color=white>" + WristMenu.buttons[11].buttonText + "</color>"))
                {
                    Page1 = false;
                    Page2 = false;
                    Page4 = false;
                    Page6 = false;
                    Page5 = false;
                    Page7 = false;
                    Page3 = false;
                    Page8 = false;
                    Page10 = false;
                    Settings = false;
                    Page9 = !Page9;
                }
                if (Page9)
                {
                    float scrollHeight = WristMenu.CatButtons9.Count * (20 + 7 + 99);
                    scrollPosition = GUI.BeginScrollView(new Rect(100, 15, 150, 250), scrollPosition, new Rect(0, 0, Screen.width - 40, scrollHeight + 20));
                    for (int i = 0; i < WristMenu.CatButtons9.Count; i++)
                    {
                        Rect buttonRect = new Rect(10, 15 + i * (20 + 7), 150, 20);
                        if (GUI.Button(buttonRect, "<color=white>" + WristMenu.CatButtons9[i].buttonText + "</color>"))
                        {
                            WristMenu.CatButtons9[i].enabled = !WristMenu.CatButtons9[i].enabled;
                            WristMenu.lastPressedButtonIndex = i;
                            GorillaTagger.Instance.offlineVRRig.PlayHandTapLocal(Mods.ButtonSound, false, 0.1f);
                        }
                    }
                    GUI.EndScrollView();
                }
                if (GUI.Button(new Rect(10f, 234f, 90f, 20f), "<color=white>" + WristMenu.buttons[12].buttonText + "</color>"))
                {
                    Page1 = false;
                    Page2 = false;
                    Settings = false;
                    Page3 = false;
                    Page4 = false;
                    Page5 = false;
                    Page6 = false;
                    Page7 = false;
                    Page8 = false;
                    Page9 = false;
                    Page10 = !Page10;
                }
                if (Page10)
                {
                    float buttonHeight = 20;
                    float scrollViewHeight = WristMenu.CatButtons10.Count * (buttonHeight + 7 + 99);
                    scrollPosition = GUI.BeginScrollView(new Rect(100, 15, 150, 250), scrollPosition, new Rect(0, 0, Screen.width - 40, scrollViewHeight + 20));
                    for (int i = 0; i < WristMenu.CatButtons10.Count; i++)
                    {
                        Rect buttonRect = new Rect(10, 15 + i * (buttonHeight + 7), 150, buttonHeight);
                        if (GUI.Button(buttonRect, "<color=white>" + WristMenu.CatButtons10[i].buttonText + "</color>"))
                        {
                            WristMenu.CatButtons10[i].enabled = !WristMenu.CatButtons10[i].enabled;
                            WristMenu.lastPressedButtonIndex = i;
                            GorillaTagger.Instance.offlineVRRig.PlayHandTapLocal(Mods.ButtonSound, false, 0.1f);
                        }
                    }
                    GUI.EndScrollView();
                }
            }
        }
        public void Update()
        {
            if (UnityInput.Current.GetKeyDown(KeyCode.Insert)) // insert (INS) to open and close the gui, u can change this to whatever u want by remove the "KeyCode.Insert" with "KeyCode." then whatever key u want
            {
                open = !open;
            }
        }
        #endregion
        #region Vars
        private bool open = true;
        public bool Settings { get; private set; }
        public bool Page1 { get; private set; }
        public bool Page2 { get; private set; }
        public bool Page3 { get; private set; }
        public bool Page4 { get; private set; }
        public bool Page5 { get; private set; }
        public bool Page6 { get; private set; }
        public bool Page7 { get; private set; }
        public bool Page8 { get; private set; }
        public bool Page9 { get; private set; }
        public bool Page10 { get; private set; }
        static Vector2 scrollPosition;
        #endregion
    }
}
